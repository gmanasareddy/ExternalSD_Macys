package com.macy.filegenie.ui.home;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.macy.filegenie.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExtensionsAdapter extends RecyclerView.Adapter<ExtensionsAdapter.MyViewHolder> {

    private List<Integer> frequenciesList;
    private HashMap<Integer, List<String>> sourceHashMap;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView text1, text2;
        public MyViewHolder(View view) {
            super(view);
            text1 = (TextView) view.findViewById(R.id.text1);
            text2 = (TextView) view.findViewById(R.id.text2);
        }
    }


    public ExtensionsAdapter(HashMap<Integer, List<String>> sourceHashMap) {
        this.sourceHashMap = sourceHashMap;
        this.frequenciesList = new ArrayList<>(sourceHashMap.keySet());
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_layout, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Integer currentFrequency = frequenciesList.get(position);
        String toShow = sourceHashMap.get(currentFrequency).get(0);
        holder.text1.setText(toShow);
        toShow = "Found " + currentFrequency + " files";
        holder.text2.setText(toShow);
    }

    @Override
    public int getItemCount() {
        return frequenciesList.size();
    }
}