package com.macy.filegenie.services;

public final class CONSTANTS {

    public interface ACTION {
        String STARTFOREGROUND_ACTION = "com.macy.filegenie.services.FileScanService.action.startforeground";
        String STOPFOREGROUND_ACTION = "com.macy.filegenie.services.FileScanService.action.stopforeground";
    }

    public interface NOTIFICATION_ID {
        int FOREGROUND_SERVICE = 101;
    }

    public interface BRODCAST_VALUES {
        String NAME = "com.macy.filegenie.services.FileScanService";
        String SCAN_COMPLETE = "IsScanComplete";
        String SCAN_RESULT_JSON = "scan_result_json";
    }
}
