package com.macy.filegenie.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.macy.filegenie.R;
import com.macy.filegenie.model.ScanResult;
import com.macy.filegenie.services.FileScanService;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;


/**
 * HomeActivity
 * This handles only view part. Here, activity is just responsible for updating UI elements and
 * providing helpers for updating the UI components for others. Others can interact with the activity
 * using HomeView which is the interface implemented by this Activity.
 */

public class HomeActivity extends AppCompatActivity implements HomeView {

    private static final String TAG = "HomeActivity";
    HomePresenter presenter;
    ExtensionsAdapter adapter;
    FileAdapter fileAdapter;

    @Bind(R.id.btn_startScan)
    Button startScan;
    @Bind(R.id.btn_stopScan)
    Button stopScan;
    @Bind(R.id.pb_scanning)
    ProgressBar progressBar;
    @Bind(R.id.scanComplete)
    TextView scanCompleteStatus;
    @Bind(R.id.avgFileSize)
    TextView avgFileSize;
    @Bind(R.id.fileScanCount)
    TextView filesScanCount;
    @Bind(R.id.topExtensionsList)
    RecyclerView topExtensionsList;
    @Bind(R.id.biggesFileList)
    RecyclerView biggestFileList;

    String toShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.v(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        ButterKnife.bind(this);
        updateScanUI(FileScanService.getIsRunning());
        presenter = new HomePresenter(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        presenter.destroy();
    }

    private void updateScanUI(boolean currentScanStatus) {
        if (currentScanStatus) {
            progressBar.setVisibility(View.VISIBLE);
            startScan.setVisibility(View.GONE);
            stopScan.setVisibility(View.VISIBLE);
        } else {
            stopScan.setVisibility(View.GONE);
            startScan.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
        }
    }

    @OnClick(R.id.btn_startScan)
    public void handleStartScan() {
        updateScanUI(true);
        presenter.startScanning();
    }

    @OnClick(R.id.btn_stopScan)
    public void handleStopScan() {
        presenter.stopScanning();
        updateScanUI(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        presenter.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        presenter.onPause();
    }

    @Override
    public void updateFilesScanResults(ScanResult scanResult, boolean isComplete) {
        if (isComplete) {
            updateScanUI(false);
        }
        toShow = "Scan complete: " + isComplete;
        scanCompleteStatus.setText(toShow);
        toShow = "Files scanned so far: " + scanResult.getScannedFilesCount();
        filesScanCount.setText(toShow);
        toShow = "Average file size: " + scanResult.getAverageFileSizeAsString();
        avgFileSize.setText(toShow);

        adapter = new ExtensionsAdapter(scanResult.getTopExtensions(5));
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        topExtensionsList.setLayoutManager(mLayoutManager);
        topExtensionsList.setItemAnimator(new DefaultItemAnimator());
        topExtensionsList.setAdapter(adapter);

        fileAdapter = new FileAdapter(scanResult.getBiggestFiles());
        RecyclerView.LayoutManager mLayoutManager2 = new LinearLayoutManager(getApplicationContext());
        biggestFileList.setLayoutManager(mLayoutManager2);
        biggestFileList.setItemAnimator(new DefaultItemAnimator());
        biggestFileList.setAdapter(fileAdapter);
    }

    @Override
    public Context getContext() {
        return getApplicationContext();
    }

    @Override
    public AppCompatActivity getCurrentActivity() {
        return this;
    }

}
