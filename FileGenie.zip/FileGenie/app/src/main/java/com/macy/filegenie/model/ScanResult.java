package com.macy.filegenie.model;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class ScanResult {
    int scannedFilesCount;
    float averageFileSize;
    ArrayList<File> biggestFiles;
    HashMap<String, Integer> fileExtensionMap;

    public ScanResult() {
        biggestFiles = new ArrayList<>();
        fileExtensionMap = new HashMap<>();
    }

    public int getScannedFilesCount() {
        return scannedFilesCount;
    }

    public void setScannedFilesCount(int scannedFilesCount) {
        this.scannedFilesCount = scannedFilesCount;
    }

    public float getAverageFileSize() {
        return averageFileSize;
    }

    public void setAverageFileSize(float averageFileSize) {
        this.averageFileSize = averageFileSize;
    }

    public String getAverageFileSizeAsString() {
        double bytes = averageFileSize;
        if (bytes < 1024) {
            return String.format("%.2f", bytes) + " Bytes";
        }

        bytes = (bytes / 1024);
        if (bytes < 1024) {
            return String.format("%.2f", bytes) + " KB";
        }

        bytes = (bytes / 1024);
        if (bytes < 1024) {
            return String.format("%.2f", bytes) + " MB";
        }

        bytes = (bytes / 1024);
        return String.format("%.2f", bytes) + " GB";
    }

    public static String getBytesAsString(long bytes) {
        if (bytes < 1024) {
            return bytes + " Bytes";
        }

        bytes = (bytes / 1024);
        if (bytes < 1024) {
            return bytes + " KB";
        }

        bytes = (bytes / 1024);
        if (bytes < 1024) {
            return bytes + " MB";
        }

        bytes = (bytes / 1024);
        return bytes + " GB";
    }


    public ArrayList<File> getBiggestFiles() {
        return biggestFiles;
    }

    public void addNewFile(File newFile) {
        if (biggestFiles.size() < 10) {
            biggestFiles.add(newFile);
            Collections.sort(biggestFiles);
        } else if (newFile.length() > biggestFiles.get(0).length()) {
            biggestFiles.add(newFile);
            Collections.sort(biggestFiles);
            biggestFiles.remove(0);
        }
    }


    public HashMap<String, Integer> getFileExtensionMap() {
        return fileExtensionMap;
    }

    public void setFileExtensionMap(HashMap<String, Integer> fileExtensionMap) {
        this.fileExtensionMap = fileExtensionMap;
    }

    public void addExtensionMap(String extension, int count) {
        Integer currentCount = fileExtensionMap.get(extension);
        currentCount = (currentCount == null) ? count : (currentCount + count);
        fileExtensionMap.put(extension, currentCount);
    }


    public HashMap<Integer, List<String>> getTopExtensions(int count) {
        HashMap<Integer, List<String>> inverseHashMap = inverseHashMap(fileExtensionMap);
        ArrayList<Integer> extensionFrequencies = new ArrayList<>(fileExtensionMap.values());
        Collections.sort(extensionFrequencies);
        Collections.reverse(extensionFrequencies);
        HashMap<Integer, List<String>> targetHashMap = new HashMap<>();
        for (int i = 0; i < count; i++) {
            targetHashMap.put(extensionFrequencies.get(i),
                    inverseHashMap.get(extensionFrequencies.get(i)));
        }
        return targetHashMap;
    }

    private HashMap<Integer, List<String>> inverseHashMap(HashMap<String, Integer> sourceHashMap) {
        HashMap<Integer, List<String>> targetHashMap = new HashMap<>();
        for (String key : sourceHashMap.keySet()) {
            int targetFrequency = sourceHashMap.get(key);
            List<String> list;
            if (targetHashMap.containsKey(targetFrequency)) {
                list = targetHashMap.get(targetFrequency);
            } else {
                list = new ArrayList<>();
            }
            list.add(key);
            targetHashMap.put(targetFrequency, list);
        }
        return targetHashMap;
    }
}
