package com.macy.filegenie.services;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import android.support.v7.app.NotificationCompat;
import android.util.Log;

import com.google.gson.Gson;
import com.macy.filegenie.model.ScanResult;

import java.io.File;
import java.util.ArrayList;

public class FileScanService extends Service {
    static boolean IS_RUNNING = false;
    private static final String TAG = "FileScanService";
    private final String EXTERNAL_STORAGE_PATH = Environment.getExternalStorageDirectory().getPath();
    private ArrayList<File> allFiles;
    private float totalFileSize;
    private ScanResult currentScanResult;


    public FileScanService() {
        allFiles = new ArrayList<>();
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.v(TAG, "Received action: " + intent.getAction());

        switch (intent.getAction()) {
            case CONSTANTS.ACTION.STARTFOREGROUND_ACTION:
                showNotification();
                allFiles.clear();
                currentScanResult = new ScanResult();
                totalFileSize = 0;
                File rootDirectory = new File(EXTERNAL_STORAGE_PATH);
                scanDirectory(rootDirectory);
                publishResults(currentScanResult, true);
                IS_RUNNING = true;
                break;
            case CONSTANTS.ACTION.STOPFOREGROUND_ACTION:
                stopForeground(true);
                stopSelf();
                IS_RUNNING = false;
                break;
        }
        return START_STICKY;
    }

    private void showNotification() {
        Notification notification = new NotificationCompat.Builder(this).build();
        startForeground(CONSTANTS.NOTIFICATION_ID.FOREGROUND_SERVICE, notification);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void scanDirectory(File directoryReference) {
        for (File currentRef : directoryReference.listFiles()) {
            if (currentRef.isDirectory()) {
                scanDirectory(currentRef);
            } else if (currentRef.isFile()) {
                allFiles.add(currentRef);
                currentScanResult.setScannedFilesCount(allFiles.size());
                totalFileSize += currentRef.length();
                currentScanResult.setAverageFileSize(totalFileSize / allFiles.size());
                String extension = getExtension(currentRef.getName());
                currentScanResult.addNewFile(currentRef);
                if (!extension.isEmpty()) {
                    currentScanResult.addExtensionMap(extension, 1);
                }
            }
        }
    }

    private void publishResults(ScanResult scanResult, boolean isComplete) {
        Intent intent = new Intent(CONSTANTS.BRODCAST_VALUES.NAME);
        intent.putExtra(CONSTANTS.BRODCAST_VALUES.SCAN_COMPLETE, isComplete);
        Gson gson = new Gson();
        String resultJson = gson.toJson(scanResult);
        intent.putExtra(CONSTANTS.BRODCAST_VALUES.SCAN_RESULT_JSON, resultJson);
        sendBroadcast(intent);
    }

    public static boolean getIsRunning() {
        return IS_RUNNING;
    }

    private String getExtension(String filePath) {
        boolean hiddenFile = (filePath.charAt(0) == '.');
        int extStart = filePath.lastIndexOf(".");
        if (!hiddenFile && (extStart > 0)) {
            return filePath.substring(filePath.lastIndexOf("."));
        }
        return "";
    }
}