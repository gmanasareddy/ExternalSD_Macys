package com.macy.filegenie.ui.home;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.google.gson.Gson;
import com.macy.filegenie.model.ScanResult;
import com.macy.filegenie.services.CONSTANTS;
import com.macy.filegenie.services.FileScanService;

public class HomePresenter {
    HomeView view;

    public HomePresenter(HomeView view) {
        this.view = view;
    }

    protected void onResume() {
        view.getContext().registerReceiver(receiver, new IntentFilter(CONSTANTS.BRODCAST_VALUES.NAME));
    }

    protected void onPause() {
        view.getContext().unregisterReceiver(receiver);
    }

    public void destroy() {
        stopScanning();
    }

    public void startScanning() {
        Intent serviceIntent = new Intent(view.getCurrentActivity(), FileScanService.class);
        serviceIntent.setAction(CONSTANTS.ACTION.STARTFOREGROUND_ACTION);
        view.getContext().startService(serviceIntent);
    }

    public void stopScanning() {
        Intent serviceIntent = new Intent(view.getCurrentActivity(), FileScanService.class);
        serviceIntent.setAction(CONSTANTS.ACTION.STOPFOREGROUND_ACTION);
        view.getContext().startService(serviceIntent);
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                String resultJson = bundle.getString(CONSTANTS.BRODCAST_VALUES.SCAN_RESULT_JSON);
                Gson gson = new Gson();
                ScanResult scanResult = gson.fromJson(resultJson, ScanResult.class);
                view.updateFilesScanResults(scanResult, bundle.getBoolean(CONSTANTS.BRODCAST_VALUES.SCAN_COMPLETE));
                stopScanning();
            }
        }
    };
}
