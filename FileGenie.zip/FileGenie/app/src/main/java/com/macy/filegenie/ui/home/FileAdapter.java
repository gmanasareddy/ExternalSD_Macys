package com.macy.filegenie.ui.home;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.macy.filegenie.R;
import com.macy.filegenie.model.ScanResult;

import java.io.File;
import java.util.List;

public class FileAdapter extends RecyclerView.Adapter<FileAdapter.MyViewHolder> {
    private List<File> fileList;

    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView text1, text2;

        public MyViewHolder(View view) {
            super(view);
            text1 = (TextView) view.findViewById(R.id.text1);
            text2 = (TextView) view.findViewById(R.id.text2);
        }
    }


    public FileAdapter(List fileList) {
        this.fileList = fileList;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_layout, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        File currentFile = fileList.get(position);
        String toShow = "" + ScanResult.getBytesAsString(currentFile.length());
        holder.text1.setText(toShow);
        toShow = currentFile.getName();
        holder.text2.setText(toShow);
    }

    @Override
    public int getItemCount() {
        return fileList.size();
    }
}
