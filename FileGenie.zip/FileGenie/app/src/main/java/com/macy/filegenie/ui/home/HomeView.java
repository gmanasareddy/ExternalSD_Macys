package com.macy.filegenie.ui.home;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.macy.filegenie.model.ScanResult;

public interface HomeView {
    Context getContext();

    AppCompatActivity getCurrentActivity();

    void updateFilesScanResults(ScanResult filesScanCount, boolean isComplete);
}
