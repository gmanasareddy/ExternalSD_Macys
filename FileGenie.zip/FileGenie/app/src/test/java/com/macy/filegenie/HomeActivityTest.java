/**
 * Created by rchandu on 4/14/16.
 */

package com.macy.filegenie;

import android.os.Build;
import android.widget.Button;

import com.macy.filegenie.ui.home.HomeActivity;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricGradleTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


@Config(constants = BuildConfig.class, sdk = Build.VERSION_CODES.LOLLIPOP)
@RunWith(RobolectricGradleTestRunner.class)
public class HomeActivityTest {
    private HomeActivity activity;


    @Before
    public void setup() throws Exception {
        activity = Robolectric.buildActivity(HomeActivity.class).create().get();
    }

    @Test
    public void checkActivityNotNull() throws Exception {
        assertNotNull(activity);
    }

    @Test
    public void initialButtonShowStart() throws Exception {
        Button view = (Button) activity.findViewById(R.id.btn_scanHandler);
        assertNotNull(view);
        String expectedText = activity.getResources().getString(R.string.startText);
        assertEquals(expectedText, view.getText());
    }
}
